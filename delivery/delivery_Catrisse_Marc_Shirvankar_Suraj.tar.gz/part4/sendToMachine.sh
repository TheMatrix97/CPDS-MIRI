#!/bin/bash
export LD_LIBRARY_PATH=/opt/cuda/4.1/lib64
mnsubmit submit-extrae.sh

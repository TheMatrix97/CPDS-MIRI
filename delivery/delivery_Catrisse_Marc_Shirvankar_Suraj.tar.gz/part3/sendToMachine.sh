#!/bin/bash
mnsubmit submit-extrae-mpi.sh
